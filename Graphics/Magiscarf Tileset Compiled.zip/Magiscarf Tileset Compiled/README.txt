No credit needed for me, all credit goes to Magiscarf in Magiscarf_Credits.txt! All links are included as well.

The Outdoor tileset is quite large, and can make RPG Maker lag a bit when switching between maps in the editor. But I haven't noticed much lag in-game.

Unfortunately, the last 5-10% of tiles in the Outdoor tileset goes beyond RPG Maker's limits, so those tiles will just show a blank tile in the editor.

With that said, feel free to select the tiles you need and put them in a much more 'brief' tileset. You can either use your image editor of choice(pain.net, krita, etc.) or try out the Tileset Carver: https://pokemonworkshop.com/en/articles/tileset-carver

Also note that I've left the first row of each tileset open, as to allow for additional autotiles. I haven't figured out how to do it myself, but I'm pretty sure you need the first 8 tiles open to make it available.

Apologies for the poor formatting and organization, but I hope these help!





For the autotiles, try to familiarize yourself with them first and how they look in-game.

The main ones involving the different shades of water are formatted as 'extended' autotiles, so the corners won't appear in the editor, but will show in game. More info on the 'extended' format here: https://essentialsdocs.fandom.com/wiki/Tilesets

The waterfalls are broken up into 4 parts each. The first waterfall fits well with the softer-textured tiles, and waterfall_2 fits with the rougher-textured tiles. Check out Magiscarf's examples here:

Waterfall - https://www.deviantart.com/magiscarf/art/Day-and-Night-735626814

Waterfall_2 - https://www.deviantart.com/magiscarf/art/Old-River-Bridge-705696000 and https://www.deviantart.com/magiscarf/art/Sample-688521454
